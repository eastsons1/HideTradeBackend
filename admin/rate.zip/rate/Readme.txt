Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/5-star-rating-system-with-jquery-ajax-and-php/

### Instructions ###

1. Load attached posts and post_rating sql files in your database.
2. Update config.php file.